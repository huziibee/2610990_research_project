# Pilot-100 v6 — all 100 route decisions explicitly approved by author

**Date:** 2026-10-19  
**Decision source:** The dataset author and final human adjudicator explicitly submitted `approve` for all 100 candidate record IDs.  
**Review scope:** `terminal_strategy` and `strategy_sequence` for all 100 records; CA-0239 capability `capable` was separately affirmed; NEW-0100 inclusion was separately approved.

## Result

| Measure | Value |
|---|---:|
| Records in v6 | 100 |
| Human author-approved route decisions | **100** |
| Unapproved route decisions in this round | **0** |
| Execute | **74** |
| Clarify | **26** |
| Source items drawn from original Pilot-120 | 99 |
| Newly created synthetic evaluation items | 1 |

**Approval does not certify every gold field.** No fresh independent blinded human judgments, nor individual human rechecks of all CPC fields, ambiguity labels or legacy provenance, are asserted. The author approved the pre-existing v4 proposed route/strategy sequence; historical `gold_status`, `gold_lifecycle`, `field_status`, and `human_gate_required` remain historical rather than rewritten as though two annotators had re-adjudicated each field.

## Explicit new corrections relative to initial 99-case gold

| Record | Original | Author-approved | Clarification question |
|---|---|---|---|
| CA-0029 — Library display stand | execute | **clarify** | Where should I move the amber PENDING display stand? |
| CA-0239 — Train-station cleaning cart | execute | **clarify** | Where should I move the amber PENDING cleaning cart? |
| CA-0565 — Airport sign board | execute | **clarify** | Where should I move the yellow PENDING sign board? |

CA-0239: The user additionally declared the robot **capable** of moving the cart. This human attestation does not change the original robot capability text, which does not positively describe moving that cart.

## Renamed 100th record

- **Previous identifier:** `NEW-0100`.
- **New native identifier:** `CA-1001` (standard `CA-####` form, avoiding collision with the original 1000-item ID range).
- **Display title:** Museum plinth.
- **Approved strategy:** `['silently_resolve','execute']`; **route:** `execute`.
- **Provenance:** Assistant-authored synthetic scenario, excluded from frozen Pilot-120; included by explicit author decision.
- **Integrity:** Apart from the record's native ID, its original command, scene, dialogue, capability context and annotation fields are unchanged. The old identifier remains an alias in the audit and in the archived v4/v5 sources.

## Deliverable guidance

- `data/pilot_100_author_route_gold_v6.jsonl` is the **author-approved 100-route key**, with per-row provenance and approval status.
- `data/pilot_100_gold_v6_NATIVE_SCHEMA.jsonl` retains native annotation field shapes; only the synthetic ID changes from v4.
- `data/pilot_100_gold_v6_WITH_AUTHOR_REVIEW_STATUS.jsonl` attaches scoped human-approval metadata.
- `data/source_100_v6.jsonl` contains the full source instructions, scene, dialogue and capabilities.
- `human_review/ALL_100_AUTHOR_REVIEW_STATUS_v6.jsonl` is the full 100-row decision/status record.
- `audit/ALL_100_EXPLICIT_APPROVALS_v6.jsonl` contains evidence hashes and per-row audit entries.
- `archive/Pilot_100_Author_Human_Adjudication_v5.zip` nests the original v4 data and earlier audit archives, preserving the complete provenance chain.
- `MANIFEST_v6.json` provides file SHA-256 hashes; run `python verify_package.py` after extracting the ZIP.

## Scientific restrictions

These 100 cases remain a **protected held-out evaluation set**: no training, prompt tuning, or model selection based on the protected examples. Results derived from them should distinguish *author-approved routes* from a claim that all underlying structured annotation fields or source scenarios were independently revalidated. In particular, synthetic `CA-1001` must not be represented as originating from an external corpus or the frozen Pilot-120.
