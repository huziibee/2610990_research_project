from pathlib import Path
from collections import Counter
import hashlib,json,zipfile
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST_v6.json').read_text())
for item in m['files']:
 p=r/item['path'];assert p.is_file(),item['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
rows=lambda p:[json.loads(x) for x in (r/p).read_text().splitlines() if x.strip()]
src=rows('data/source_100_v6.jsonl')
gold=rows('data/pilot_100_gold_v6_NATIVE_SCHEMA.jsonl')
route=rows('data/pilot_100_author_route_gold_v6.jsonl')
st=rows('human_review/ALL_100_AUTHOR_REVIEW_STATUS_v6.jsonl')
ledger=rows('audit/ALL_100_EXPLICIT_APPROVALS_v6.jsonl')
assert len(src)==len(gold)==len(route)==len(st)==len(ledger)==100
ids=[x['record_id'] for x in src]
assert ids==[x['record_id'] for x in gold]==[x['record_id'] for x in route]==[x['record_id'] for x in st]==[x['record_id'] for x in ledger]
assert len(set(ids))==100 and 'CA-1001' in ids and 'NEW-0100' not in ids
assert Counter(x['terminal_strategy'] for x in gold)=={'execute':74,'clarify':26}
assert all(x['human_review_status']=='approved_by_author' for x in route)
assert all(x['human_route_review_status']=='explicit_author_approved_route' for x in st)
assert all(x['human_decision']=='approve' for x in ledger)
assert len([x for x in st if x['case_origin']=='assistant_synthetic_outside_pilot120'])==1
with zipfile.ZipFile(r/'archive/Pilot_100_Author_Human_Adjudication_v5.zip') as z:
 with zipfile.ZipFile(__import__('io').BytesIO(z.read('archive/Pilot_100_Human_Adjudication_v4_UNAPPROVED.zip'))) as v4z:
  oldsrc=[json.loads(x) for x in v4z.read('source_100_candidate_v4.jsonl').decode().splitlines() if x]
  oldgold=[json.loads(x) for x in v4z.read('pilot_100_proposed_gold_v4_UNAPPROVED.jsonl').decode().splitlines() if x]
  assert src[:-1]==oldsrc[:-1] and gold[:-1]==oldgold[:-1]
  assert {k:v for k,v in src[-1].items() if k!='record_id'}=={k:v for k,v in oldsrc[-1].items() if k!='record_id'}
  assert {k:v for k,v in gold[-1].items() if k!='record_id'}=={k:v for k,v in oldgold[-1].items() if k!='record_id'}
  assert oldsrc[-1]['record_id']=='NEW-0100' and src[-1]['record_id']=='CA-1001'
print('PASS: 100 explicit human route approvals, source+gold integrity, 74/26, no unapproved records; verified',len(m['files']),'file hashes')
